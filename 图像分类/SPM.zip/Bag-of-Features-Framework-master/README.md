# Bag-of-Features-Framework
This is a simple Bag-of-Features framework for image classification and retrieval developed by OpenCV.
By using some APIs offered by OpenCV, we can easily build a BoF model to handle image classifition task. 
For examples, in an invoice classification task, we use this BoF to calssify and we get 0.99 accuracy.


Please visit my blog for more details.http://www.cnblogs.com/skyfsm/p/8097397.html


